﻿using UnityEngine;
using System.Collections;

public class BuildingScript : MonoBehaviour 
{
    float resetDistance = 202f;
    float resetCoordinate_Z = -20.44f;
    public float speed = -5f;
    public AirPlaneScript airPlaneScript;
    

	// Update is called once per frame
	void Update () 
    {
        MoveForward();
	}

    void MoveForward()
    {
        if (airPlaneScript.isAlive)
        {
            transform.Translate(transform.InverseTransformDirection(Vector3.forward) * speed * Time.deltaTime);
            if (transform.position.z <= resetCoordinate_Z)
            {
                transform.Translate(transform.InverseTransformDirection(Vector3.forward) * resetDistance);
            }
        }
    }
}
