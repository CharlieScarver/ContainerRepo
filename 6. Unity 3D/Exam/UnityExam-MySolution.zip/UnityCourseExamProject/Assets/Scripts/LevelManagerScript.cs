﻿using UnityEngine;
using System.Collections;

public class LevelManagerScript : MonoBehaviour
{
    public PlayerControllerScript playerScript;
    public GameObject UIMenu;
    public Transform[] spawnPositions;
    public GameObject floatingLandPrefab;
    FloorPieceScript[] floorPieces;
    float nextSpawnTime;
    float minTimeBetweenLandSpawn = 1.5f;
    float maxTimeBetweenLandSpawn = 3f;

    public GameObject poolParent;
    GameObject[] pool;

    void Awake()
    {
        PopulatePool();
        floorPieces = transform.GetComponentsInChildren<FloorPieceScript>();
        nextSpawnTime = Random.Range(minTimeBetweenLandSpawn, maxTimeBetweenLandSpawn);
        PauseGame();
    }

    void Update()
    {
        if (!playerScript.isMoving)
        {
            return;
        }

        nextSpawnTime -= Time.deltaTime;

        if (nextSpawnTime <= 0f)
        {
            nextSpawnTime = Random.Range(minTimeBetweenLandSpawn, maxTimeBetweenLandSpawn);
            SpawnNewLand();
        }
    }

    void SpawnNewLand()
    {
        Transform newLand = GetFreeFloatingLand();

        if (newLand == null)
        {
            return;
        }

        newLand.position = spawnPositions[Random.Range(0, spawnPositions.Length)].position;
        newLand.gameObject.SetActive(true);
    }

    Transform GetFreeFloatingLand()
    {
        int count = pool.Length;
        for (int i = 0; i < count; i++)
        {
            if (!pool[i].activeSelf)
            {
                GameObject item = pool[i];
                return item.transform;
            }
        }

        Debug.Log("No free items in the pool");
        return null;
    }

    public void PauseGame()
    {
        int count = floorPieces.Length;

        for (int i = 0; i < count; i++)
        {
            floorPieces[i].isMoving = false;
        }

        for (int i = 0; i < pool.Length; i++)
        {
            if (pool[i].activeSelf)
            {
                pool[i].GetComponent<FloatingLandScript>().isMoving = false;
            }
        }

        playerScript.isMoving = false;
        playerScript.attachedRigidbody.Sleep();
        UIMenu.SetActive(true);
    }

    public void UnPauseGame()
    {
        int count = floorPieces.Length;

        for (int i = 0; i < count; i++)
        {
            floorPieces[i].isMoving = true;
        }

        for (int i = 0; i < pool.Length; i++)
        {
            if (pool[i].activeSelf)
            {
                pool[i].GetComponent<FloatingLandScript>().isMoving = true;
            }
        }

        playerScript.isMoving = true;
        playerScript.attachedRigidbody.WakeUp();
        UIMenu.SetActive(false);
    }

    void PopulatePool()
    {
        int count = poolParent.transform.childCount;
        pool = new GameObject[count];

        for (int i = 0; i < count; i++)
        {
            pool[i] = poolParent.transform.GetChild(i).gameObject;
        }
    }
}
