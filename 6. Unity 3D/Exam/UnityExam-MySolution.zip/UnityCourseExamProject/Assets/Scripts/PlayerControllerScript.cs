﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;

public class PlayerControllerScript : MonoBehaviour
{
    public bool isMoving;
    public bool isGrounded;
    public Rigidbody2D attachedRigidbody;
    public float charachterMovingSpeed = 2f;

    public Text scoreText;
    public AudioSource bananaSound;
    public AudioSource jumpSound;

    private bool isFacingRight = true;

    float speedMultiplier;

    Animator dumpyAnimator;

    public float jumpForce = 1000f;
    
    int score;

	// Use this for initialization
	void Start ()
    {        
        dumpyAnimator = GetComponent<Animator>();
        score = PlayerPrefs.GetInt("Score");
        scoreText.text = string.Format("Score : {0}", score);
    }
	
	// Update is called once per frame
	void Update ()
    {
        UpdateMovement();

    }


    void UpdateMovement()
    {
        if (!isMoving)
        {
            return;
        }
        
        if (Input.GetKey(KeyCode.RightArrow))
        {
            if (!isFacingRight)
            {
                isFacingRight = true;
                dumpyAnimator.transform.Rotate(0, 180, 0);
            }

            speedMultiplier = 1f;

            if (!dumpyAnimator.GetBool("Run"))
            {
                dumpyAnimator.SetBool("Run", true);
            }
        }
        else if (Input.GetKey(KeyCode.LeftArrow))
        {
            if (isFacingRight)
            {
                isFacingRight = false;
                dumpyAnimator.transform.Rotate(0, 180, 0);
            }

            speedMultiplier = -1.5f;

            if (!dumpyAnimator.GetBool("Run"))
            {
                dumpyAnimator.SetBool("Run", true);
            }            
        }
        else
        {
            speedMultiplier = -0.8f;

            if (dumpyAnimator.GetBool("Run"))
            {
                dumpyAnimator.SetBool("Run", false);
            }

        }

        if (Input.GetKey(KeyCode.UpArrow) && isGrounded)
        {
            attachedRigidbody.AddRelativeForce(new Vector2(0, jumpForce), ForceMode2D.Impulse);
            isGrounded = false;
            jumpSound.Play();
        }

        if (Input.GetKey(KeyCode.Space))
        {
            dumpyAnimator.SetTrigger("Attack");
        }
        
        attachedRigidbody.velocity = new Vector2(speedMultiplier * charachterMovingSpeed * Time.deltaTime, attachedRigidbody.velocity.y);
    }
    

    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.collider.CompareTag("Land") && coll.transform.position.y < transform.position.y)
        {
            isGrounded = true;
        }
        else if (coll.collider.CompareTag("ResetCollider"))
        {
            score = 0;
            PlayerPrefs.SetInt("Score", score);
            SceneManager.LoadScene("GameScene");
        }
    }

    void OnCollisionStay2D(Collision2D coll)
    {
        if (coll.collider.CompareTag("Land") && coll.transform.position.y < transform.position.y && !isGrounded)
        {
            isGrounded = true;
        }
    }

    void OnCollisionExit2D(Collision2D coll)
    {
        if (coll.collider.CompareTag("Land") && coll.transform.position.y < transform.position.y)
        {
            isGrounded = false;
        }
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.CompareTag("Banana"))
        {
            score++;
            PlayerPrefs.SetInt("Score", score);
            scoreText.text = string.Format("Score : {0}", score);
            Destroy(coll.gameObject);
            bananaSound.Play();
        }        
    }
}
